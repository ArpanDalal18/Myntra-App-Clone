const LoadingSpinner = () => {
  return (
    <center className="spinner">
      <button className="btn btn-primary" style={{ width: "10rem", height: "5rem" }} type="button" disabled>
        <span className="spinner-border spinner-border-sm" aria-hidden="true"></span>
        &nbsp;
        <span role="status">Loading...</span>
      </button>
    </center>
  )
}

export default LoadingSpinner;